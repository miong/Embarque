#define  _GNU_SOURCE
#include<stdio.h>
#include<stdlib.h>
#include<sched.h>
#include<pthread.h>
#include<unistd.h>
#include<semaphore.h>

#define max sched_get_priority_max(SCHED_FIFO)
#define min sched_get_priority_min(SCHED_FIFO)
#define middle (max-min)/2


void threadsCreation(void);
