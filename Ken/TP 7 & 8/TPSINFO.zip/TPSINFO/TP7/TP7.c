#include"TP7.h"
/*thread A de haute priorité
 * 
 * B de moyenne
 * 
 * et C de basse priorité
 * 
 * 
 **/

pthread_t thA,thB,thC;
pthread_mutex_t mutex;
sem_t sem;

int invers=0;
int inversion=0;

void * HighPrio(void * arg){

	//se bloquer en attendant que Low s'execute	
	sem_wait(&sem);
	
	printf("thread de haute priorité commence\n");
	printf("thread de haute priorité demande le verrou\n");
	// donner la main à Middle aprés s'etre bloqué sur mutex
	sem_post(&sem);
	//*****************Section critique***********************
	if(pthread_mutex_lock(&mutex)!=0){
		perror("pthread_mutex_lock High");
		exit(EXIT_FAILURE);
	
	}
	
	printf("thread de haute priorité a obtenu le verrou\n");
	
	if(pthread_mutex_unlock(&mutex)!=0){
		perror("pthread_mutex_unlock High");
		exit(EXIT_FAILURE);
	
	}
	//********************************************************	

	
	printf("thread de haute priorité relache le verrou\n");
	printf("thread de haute priorité termine\n");
	
	if(invers==1)
	inversion=1;
	
	return NULL;
	}
	
	
void * MidPrio(void * arg){
	//se bloquer jusqu'a ce que Low s'execute
	sem_wait(&sem);
	printf("thread de moyenne priorité commence\n");
	invers=1;
	printf("thread de moyenne priorité termine\n");
		
	return NULL;
	}
void * LowPrio(void * arg){
	
	printf("thread de faible priorité commence\n");
	printf("thread de faible priorité demande le verrou\n");
	//*****************Section critique***********************
	if(pthread_mutex_lock(&mutex)!=0){
		perror("pthread_mutex_lock Low");
		exit(EXIT_FAILURE);
	}	
	printf("thread de faible priorité a obtenu le verrou\n");
	//donner la main à High
	sem_post(&sem);
	
	
	
	printf("thread de faible priorité relache le verrou\n");	
	if(pthread_mutex_unlock(&mutex)!=0){
		perror("pthread_mutex_unlock Low");
		exit(EXIT_FAILURE);
	
	}
	//********************************************************	
	
	printf("thread de faible priorité termine\n");

	return NULL;
	}
	
	

int main(int argc, char ** argv){
	
		if(argc!=2){
			perror("vous devez specifiez l'option\nINHERIT: avec héritage de priorite\nNO_INHERIT: sans héritage de priorité");
			exit(EXIT_FAILURE);
		}
			
				
		struct sched_param sched;
		
		cpu_set_t cpu_set;
		CPU_ZERO(&cpu_set);//vider cpu_set
		CPU_SET(0,&cpu_set);// ajouter cpu 0 à  cpu_set
		//execution sur un seul coeur
		if (sched_setaffinity(0,sizeof(cpu_set),&cpu_set)!= 0){
			perror("sched_setaffinity");
			exit(1);
		}
		if(strcmp(argv[1],"NO_INHERIT")==0){
			if (pthread_mutex_init(&mutex,NULL)!=0){
			perror("pthread_mutex_init NO_INHERIT");
            exit (EXIT_FAILURE);
			}
		}
		else{
			if(strcmp(argv[1],"INHERIT")==0){
				pthread_mutexattr_t mutex_attr;
				if(pthread_mutexattr_init(&mutex_attr)!=0){
					perror("pthread_mutexattr_init");
					exit(1);
				}
				if (pthread_mutexattr_setprotocol(&mutex_attr,PTHREAD_PRIO_INHERIT)!=0){
					perror("pthread_mutexattr_setprotocol");
					exit( EXIT_FAILURE);
				}
				if (pthread_mutex_init(&mutex,&mutex_attr)!=0){
					perror("pthread_mutex_init INHERIT");
					exit( EXIT_FAILURE);
				}
			
			}
			else{
				perror("option incorrecte\n");
				exit(1);
			}
		}
		
		
	
		//semaphores dont le compteur est initialisé à zero
		if(sem_init(
		&sem,0,0)!=0){
			perror("sem_init");
			exit(-1);
		}
		
		
		//appel à la fonction qui crée les threads
		threadsCreation();
	

		//attendre la terminaison du thread LOW
		pthread_join(thC,NULL);
		
		if(inversion==1)
			printf("\n il y a eu inversion de priorité\n");
		else
			printf("\n il N'y a PAS eu inversion de priorité\n");

	
	return EXIT_SUCCESS;
	}
	
	
	
	
	
	void threadsCreation(){
		
		pthread_attr_t attrA,attrB,attrC;
		struct sched_param schedA,schedB,schedC;
	
		if(pthread_attr_init(&attrA)!=0){
			perror("pthread_attr_init A");
			exit(1);
		}
		
		if(pthread_attr_init(&attrB)!=0){
			perror("pthread_attr_init B");
			exit(1);
	
		}
		
		if(pthread_attr_init(&attrC)!=0){
			perror("pthread_attr_init C");
			exit(1);
		}
		
		if (pthread_attr_setinheritsched(&attrA,PTHREAD_EXPLICIT_SCHED)!=0){
				perror("pthread_attr_setinheritsched A");
	         exit( EXIT_FAILURE);
		}
		if (pthread_attr_setinheritsched(&attrB,PTHREAD_EXPLICIT_SCHED)!=0){
			perror("pthread_attr_setinheritsched B");	  
            exit( EXIT_FAILURE);
		}
		if (pthread_attr_setinheritsched(&attrC,PTHREAD_EXPLICIT_SCHED)!=0){
			perror("pthread_attr_setinheritsched C");
			exit( EXIT_FAILURE);
		}
	

		if (pthread_attr_setschedpolicy(&attrA,SCHED_FIFO)!=0){
			perror("pthread_attr_setschedpolicy A");
            exit( EXIT_FAILURE);
		}
		
		if (pthread_attr_setschedpolicy(&attrB,SCHED_FIFO)!=0){
			perror("pthread_attr_setschedpolicy B");
            exit( EXIT_FAILURE);
		}
		
		if (pthread_attr_setschedpolicy(&attrC,SCHED_FIFO)!=0){
			perror("pthread_attr_setschedpolicy C");
            exit( EXIT_FAILURE);
		}
		
		schedA.sched_priority=max;
	
		if(pthread_attr_setschedparam(&attrA,
			&schedA)!=0){
			perror("pthread_attr_setschedparam A");
			exit(1);
		}

		schedB.sched_priority=middle;
	
		if(pthread_attr_setschedparam(&attrB,
			&schedB)!=0){
			perror("pthread_attr_setschedparam B");
			exit(1);
		}
		
		schedC.sched_priority=min;
		
		if(pthread_attr_setschedparam(&attrC,
			&schedC)!=0){
			perror("pthread_attr_setschedparam C");
			exit(1);
		}	
		if(pthread_create(&thB,&attrB, MidPrio, NULL)!=0){
			perror("pthread create B");
			exit(1);
		}
	
		
		if(pthread_create(&thA,&attrA, HighPrio, NULL)!=0){
			perror("pthread create A");
			exit(1);
		}
		
		if(pthread_create(&thC,&attrC, LowPrio, NULL)!=0){
			perror("pthread create C");
			exit(1);
		}
				
	}
