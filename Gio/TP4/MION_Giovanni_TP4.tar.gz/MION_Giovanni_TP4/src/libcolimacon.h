/**********************************************************************/
/*                                                                    */
/*                  TP1 - LIBCOLIMACON.H - MION GIOVANNI              */
/*                                                                    */
/**********************************************************************/

extern int colimacon(int **array, unsigned int rows, unsigned int columns);
